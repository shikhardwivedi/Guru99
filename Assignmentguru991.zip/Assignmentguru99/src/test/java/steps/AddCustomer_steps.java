package steps;

import org.openqa.selenium.WebDriver;

import actions.AddCustomer_actions;
import actions.Common_Actions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class AddCustomer_steps {
	Common_Actions common_Actions;
	AddCustomer_actions addCustomer_actions;

	public AddCustomer_steps(Common_Actions common_Actions,
			AddCustomer_actions addCustomer_actions) {
		this.common_Actions = common_Actions;
		this.addCustomer_actions = addCustomer_actions;
	}

	protected WebDriver driver;

	@Given("User is on Guru99 telecom home page")
	public void user_is_on_guru99_telecom_home_page() {
		// Write code here that turns the phrase above into concrete actions
		common_Actions.goToURL("http://demo.guru99.com/telecom/index.html");
		common_Actions.maximize();
	}

	@When("User click on Add Customer")
	public void user_click_on_add_customer() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.click_AddCustomer();

	}

	@Then("User navigate to Add Customer Page")
	public void user_navigate_to_add_customer_page() {
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String AddCust_Url = "http://demo.guru99.com/telecom/addcustomer.php";
		Assert.assertEquals(Url, AddCust_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom Add Customer";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to the correct URL....");
		}

	}

	@When("User Click on Pending Radio button")
	public void user_click_on_pending_radio_button() {
		addCustomer_actions.Radio_btn();
	}

	@When("User click and enter FirstName {string}")
	public void user_click_and_enter_first_name(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.enter_Fname(string);
	}

	@When("User click and enter LastName {string}")
	public void user_click_and_enter_last_name(String string) throws InterruptedException {
		addCustomer_actions.enter_Lname(string);
	}

	@When("User click and enter Email {string}")
	public void user_click_and_enter_email(String string) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.enter_Email(string);
	}

	@When("User click and enter Address {string}")
	public void user_click_and_enter_address(String string) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.enter_Address(string);
	}

	@When("User click and enter Phone_no {string}")
	public void user_click_and_enter_phone_no(String string) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.enter_Ph_no(string);
	}

	@Then("User click submit button")
	public void user_click_submit_button() throws Exception {
		addCustomer_actions.click_submit();
		Thread.sleep(5000);
	}

	@When("User click on Home button")
	public void user_click_on_home_button() {
		addCustomer_actions.click_Home();
	}

	@Then("User navigate to the telecom home page")
	public void user_navigate_to_the_telecom_home_page() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String home_Url = "http://demo.guru99.com/telecom/index.html";
		Assert.assertEquals(Url, home_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 telecom";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to the correct URL....");
		}
	}

	@When("User click Add Tariff plan")
	public void user_click_add_tariff_plan() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Add_Tariff_Plans();
	}

	@Then("User navigate to Add Tariff plan page")
	public void user_navigate_to_add_tariff_plan_page() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String AddTariff_Url = "http://demo.guru99.com/telecom/addtariffplans.php";
		Assert.assertEquals(Url, AddTariff_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 telecom";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to the correct URL....");
		}
	}

	@Then("User enter Monthly Rental")
	public void user_enter_monthly_rental() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_monthly_rental();
	}

	@Then("User enter Free Local Minutes")
	public void user_enter_free_local_minutes() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_Free_Local_minutes();

	}

	@Then("User enter Free International Minutes")
	public void user_enter_free_international_minutes() {

		addCustomer_actions.Enter_Free_International_Minutes();
	}

	@Then("User enter Free SmS Pack")
	public void user_enter_free_sm_s_pack() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_Free_SMS_Packs();

	}

	@Then("User enter Local Per Minutes Charges")
	public void user_enter_local_per_minutes_charges() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_Local_Per_Min();

	}

	@Then("User enter International Per Minutes Charges")
	public void user_enter_international_per_minutes_charges() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_International_per_min_charges();

	}

	@Then("User enter SMS Per Charges")
	public void user_enter_sms_per_charges() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_SMS_per_charges();
		Thread.sleep(3000);
	}

	@Then("User click on Submit button")
	public void user_click_on_submit_button() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.click_submit_Add();
	}

	@Then("User Navigate to confirmation page")
	public void user_navigate_to_confirmation_page() {
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Congrats_Url = "http://demo.guru99.com/telecom/addtariffplans.php";
		Assert.assertEquals(Url, Congrats_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 telecom";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to the correct URL....");
		}

	}

	@When("USer click on Home button")
	public void u_ser_click_on_home_button() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.click_Home_Congrats();
	}

	@Then("User Navigate to the Home Page")
	public void user_navigate_to_the_home_page() {
		// Write code here that turns the phrase above into concrete actions
//	http://demo.guru99.com/telecom/index.html
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Home_Url = "http://demo.guru99.com/telecom/index.html";
		Assert.assertEquals(Url, Home_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}

	@When("User click on Add Tariff to Customer")
	public void user_click_on_add_tariff_to_customer() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Add_tariff_to_cust();
	}

	@When("User navigate to the Add Tariff to Customer")
	public void user_navigate_to_the_add_tariff_to_customer() {
		// Write code here that turns the phrase above into concrete actions
//		http://demo.guru99.com/telecom/assigntariffplantocustomer.php
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String T_to_cust_Url = "http://demo.guru99.com/telecom/assigntariffplantocustomer.php";
		Assert.assertEquals(Url, T_to_cust_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Add Tariff Plan to Customer";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}

	@When("User enter the customer ID")
	public void user_enter_the_customer_id() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Enter_Cust_ID();
	}

	@When("User click Submit button")
	public void user_click_submit_button1() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.click_Submit_after_CID();
		Thread.sleep(2000);
	}

	@When("User navigate to the Approved Tariff page")
	public void user_navigate_to_the_approved_tariff_page() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Approved_Url = "http://demo.guru99.com/telecom/assigntariffplantocustomer.php";
		Assert.assertEquals(Url, Approved_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Add Tariff Plan to Customer";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}

	@When("User select the Approved Tariff")
	public void user_select_the_approved_tariff() throws InterruptedException {
		addCustomer_actions.scrollDown();
		Thread.sleep(2000);

		addCustomer_actions.Approved();
	}

	@When("User Click Add Tariff")
	public void user_click_add_tariff() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.Add();
	}

	@Then("User navigate to the congratulations Page")
	public void user_navigate_to_the_congratulations_page() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Cong_Url = "http://demo.guru99.com/telecom/inserttariffplantocustomer.php";
		Assert.assertEquals(Url, Cong_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom Tariff Plan";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}

	@Then("User click Home button")
	public void user_click_home_button() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.payHome();
	}

	@Then("User should navigate to home page")
	public void user_should_navigate_to_home_page() throws InterruptedException {

		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Approved_Url = "http://demo.guru99.com/telecom/index.html";
		Assert.assertEquals(Url, Approved_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom Tariff Plan";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
		Thread.sleep(3000);
	}

	@When("User click on Paybill")
	public void user_click_on_paybill() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.click_pay_bill();
	}

	@When("User navigate to Paybill page")
	public void user_navigate_to_paybill_page() {
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String P_bill_Url = "http://demo.guru99.com/telecom/billing.php";
		Assert.assertEquals(Url, P_bill_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom Billing";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}

	@When("User enter customer ID")
	public void user_enter_customer_id() {
		// Write code here that turns the phrase above into concrete actions
		addCustomer_actions.enter_Paybill_custID();
	}

	@Then("User shouldnavigate to the Paybill page")
	public void user_shouldnavigate_to_the_paybill_page() {
		System.out.println("Current Page Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title of the Page : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String P_bill_Url = "http://demo.guru99.com/telecom/billing.php";
		Assert.assertEquals(Url, P_bill_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Telecom Billing";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link navigated to another page");
		}
	}


}
