package steps;

import org.openqa.selenium.WebDriver;

import actions.Common_Actions;
import actions.Payment_actions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class Payment_steps {
	Common_Actions common_Actions;
	Payment_actions payment_actions;

	public Payment_steps(Common_Actions common_Actions,
			Payment_actions payment_actions) {
		this.common_Actions = common_Actions;
		this.payment_actions = payment_actions;
	}

	protected WebDriver driver;
	@Given("User is on payment page")
	public void user_is_on_payment_page() {
	    // Write code here that turns the phrase above into concrete actions
		common_Actions.goToURL("http://demo.guru99.com/payment-gateway/purchasetoy.php");
		common_Actions.maximize();
	}

	@When("user clicks on Quantity of item to select quantity")
	public void user_clicks_on_quantity_of_item_to_select_quantity() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		payment_actions.click_Quantity();
	    
	}

	@When("User clciks on Buy now Button")
	public void user_clciks_on_buy_now_button() throws InterruptedException {
		payment_actions.click_BuyNow();
		// Write code here that turns the phrase above into concrete actions
		  
		}
		

	@Then("User should navigate to next payment process page")
	public void user_should_navigate_to_next_payment_process_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Current Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title : " + common_Actions.getCurrentPageTitle());
		String Url = common_Actions.getCurrentUrl();
		String Pay_Url = "http://demo.guru99.com/payment-gateway/process_purchasetoy.php";
		Assert.assertEquals(Url, Pay_Url);
		String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Payment Gateway";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link took us to another page");
		}
	}

	@Then("User Enter the Card Number")
	public void user_enter_the_card_number() {
		String string = "9876543211234567";
		// Write code here that turns the phrase above into concrete actions
		payment_actions.card_Number(string);
	      
	}

	@Then("User selects Expiration month using drop down")
	public void user_selects_expiration_month_using_drop_down() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		payment_actions.select_Exp_Month();
	      
	}

	@Then("user selects Expiration year using drop down")
	public void user_selects_expiration_year_using_drop_down() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		payment_actions.select_Exp_Year();
	      
	}

	@Then("user Enter the CVV number in the text Box")
	public void user_enter_the_cvv_number_in_the_text_box() throws Exception {
	    String string = "976";
		// Write code here that turns the phrase above into concrete actions
		payment_actions.enter_CVV(string);
	      
	}

	@Then("user Clicks on Pay button")
	public void user_clicks_on_pay_button() {
	    // Write code here that turns the phrase above into concrete actions
		payment_actions.click_Pay();
	      
	}

	@Then("user should navigate to Payment Succesful page")
	public void user_should_navigate_to_payment_succesful_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Current Url : " + common_Actions.getCurrentUrl());
		System.out.println("Current Title : " + common_Actions.getCurrentPageTitle());
        String actTitle = common_Actions.getCurrentPageTitle();
		String expTitle = "Guru99 Payment Gateway";
		if (!expTitle.equalsIgnoreCase(actTitle)) {
			System.out.println("Link took us to the other page");
		}
	}
}

