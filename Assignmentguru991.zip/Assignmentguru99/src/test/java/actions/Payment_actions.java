package actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import elements.Payment_elements;
import steps.Common_steps;

public class Payment_actions {
	private WebDriver driver;
	Payment_elements payment_elements;

	public Payment_actions(Common_steps common_steps) {
		this.driver = common_steps.getDriver();
		payment_elements = new Payment_elements(driver);
	}

	public void click_Quantity() throws Exception {
		WebElement quantity = payment_elements.Quantity;
		Select select = new Select(quantity);
		select.selectByIndex(7);
		Thread.sleep(2000);
	}

	public void click_BuyNow() throws InterruptedException {
		payment_elements.Buy_Now.click();
		Thread.sleep(2000);
	}

	public void card_Number(String Card) {
		payment_elements.Card_no.click();
		payment_elements.Card_no.sendKeys(Card);
	}

	public void select_Exp_Month() throws Exception {
		WebElement exp_Month = payment_elements.Exp_Month;
		Select month = new Select(exp_Month);
		month.selectByIndex(5);
		Thread.sleep(2000);
	}

	public void select_Exp_Year() throws Exception {
		WebElement exp_Year = payment_elements.Exp_Year;
		Select year = new Select(exp_Year);
		year.selectByIndex(11);
		Thread.sleep(2000);
	}

	public void enter_CVV(String cvv) throws Exception {
		payment_elements.CVV.click();
		payment_elements.CVV.sendKeys(cvv);
		Thread.sleep(2000);
	}
	public void click_Pay() {
		payment_elements.Pay.click();
	}

	public void click_Home() {
		payment_elements.Home.click();
	}

}