package actions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import elements.AddCustomer_elements;
import steps.Common_steps;

public class AddCustomer_actions {

	private WebDriver driver;
	AddCustomer_elements addCustomer_elements;

	public AddCustomer_actions(Common_steps common_steps) {
		this.driver = common_steps.getDriver();
		addCustomer_elements = new AddCustomer_elements(driver);

	}

	public void click_AddCustomer() {
		addCustomer_elements.Add_Customer.click();
	}

	public void Radio_btn() {
		addCustomer_elements.Done.click();
	}

	public void enter_Fname(String first_name) throws Exception {
		addCustomer_elements.F_name.click();
		addCustomer_elements.F_name.sendKeys(first_name);
		Thread.sleep(2000);
	}

	public void enter_Lname(String last_name) throws InterruptedException {
		addCustomer_elements.L_name.click();
		addCustomer_elements.L_name.sendKeys(last_name);
		Thread.sleep(2000);
	}

	public void enter_Email(String email) throws InterruptedException {
		addCustomer_elements.Email.click();
		addCustomer_elements.Email.sendKeys(email);
		Thread.sleep(2000);
	}

	public void enter_Address(String address) throws Exception {
		addCustomer_elements.Address.click();
		addCustomer_elements.Address.sendKeys(address);
		Thread.sleep(2000);
	}

	public void enter_Ph_no(String Ph_no) throws InterruptedException {
		addCustomer_elements.Phone_no.click();
		addCustomer_elements.Phone_no.sendKeys(Ph_no);
		Thread.sleep(2000);
	}

	public void click_submit() {
		addCustomer_elements.Submit_btn.click();
	}

	public void click_reset() {
		addCustomer_elements.Reset_btn.click();
	}

	public void click_Home() {
		addCustomer_elements.Home.click();
	}

	public void Add_Tariff_Plans() throws Exception {
		addCustomer_elements.Click_Add_Tariff_Plan.click();
		Thread.sleep(2000);
	}

	public void Enter_monthly_rental() {
		addCustomer_elements.Monthly_Rental.click();
		addCustomer_elements.Monthly_Rental.sendKeys("231");
	}

	public void Enter_Free_Local_minutes() {
		addCustomer_elements.Local_Minutes.click();
		addCustomer_elements.Local_Minutes.sendKeys("343");
	}

	public void Enter_Free_International_Minutes() {
		addCustomer_elements.International_Minutes.click();
		addCustomer_elements.International_Minutes.sendKeys("125");
	}

	public void Enter_Free_SMS_Packs() {
		addCustomer_elements.SmS_Pack.click();
		addCustomer_elements.SmS_Pack.sendKeys("113");
	}

	public void Enter_Local_Per_Min() {
		addCustomer_elements.Local_min_charges.click();
		addCustomer_elements.Local_min_charges.sendKeys("122");
	}

	public void Enter_International_per_min_charges() {
		addCustomer_elements.International_Min_Charges.click();
		addCustomer_elements.International_Min_Charges.sendKeys("121");
	}

	public void Enter_SMS_per_charges() {
		addCustomer_elements.SMS_charges.click();
		addCustomer_elements.SMS_charges.sendKeys("120");
	}

	public void click_submit_Add() {
		addCustomer_elements.Submit_Add_Tariff_Plan.click();
	}

	public void click_Home_Congrats() throws Exception {
		addCustomer_elements.Home_Congrats.click();
		Thread.sleep(2000);
	}

	public void Add_tariff_to_cust() throws InterruptedException {
		addCustomer_elements.Add_Tar_to_Cust.click();
		Thread.sleep(2000);
	}

	public void Enter_Cust_ID() {
		addCustomer_elements.Cust_ID.sendKeys("692564");
	}

	public void click_Submit_after_CID() throws InterruptedException {
		addCustomer_elements.submit_After_CID.click();
		Thread.sleep(2000);
	}

	public void click_pay_bill() throws Exception {
		addCustomer_elements.PayBill.click();
		Thread.sleep(2000);
	}

	public void Approved() throws InterruptedException {
		
		WebElement radioBtn1 = addCustomer_elements.Radiobtn;
		((JavascriptExecutor) driver).executeScript("arguments[0].checked = true;", radioBtn1);
		
		
//		telecom_addCustomer_elements.Radiobtn.click();
		Thread.sleep(2000);

	}
	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
	}

	public void Add() throws InterruptedException {
	    addCustomer_elements.AddTariff_btn.click();
		Thread.sleep(2000);
	}

	public void payHome() {
        addCustomer_elements.pay_Home.click();
	}

	public void enter_Paybill_custID() {
		addCustomer_elements.Paybill_custID.sendKeys("692564");
	}

	public void click_paybill_submitbtn() throws InterruptedException {
		addCustomer_elements.PayBill_submit.click();
		Thread.sleep(2000);
	}
}
