package elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Payment_elements {
	WebDriver driver;

	@FindBy(xpath = "//select[@name='quantity']")
	public WebElement Quantity;
	@FindBy(xpath = "//input[@class='button special']")
	public WebElement Buy_Now;
	@FindBy(xpath = "//input[@id='card_nmuber']")
	public WebElement Card_no;
	@FindBy(xpath = "//select[@id='month']")
	public WebElement Exp_Month;
	@FindBy(xpath = "//select[@id='year']")
	public WebElement Exp_Year;
	@FindBy(xpath = "//input[@id='cvv_code']")
	public WebElement CVV;
	@FindBy(xpath = "//input[@name='submit']")
	public WebElement Pay;
	@FindBy(xpath = "//a[.='Home']")
	public WebElement Home;

	public Payment_elements(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
