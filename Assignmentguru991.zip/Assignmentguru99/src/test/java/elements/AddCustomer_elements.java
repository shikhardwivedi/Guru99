package elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCustomer_elements {
	WebDriver driver;
	@FindBy(xpath = "//div[@class='flex-item left']//a[.='Add Customer']")
	public WebElement Add_Customer;
	@FindBy(xpath = "//label[.='Done']")
	public WebElement Done;
	@FindBy(xpath = "//input[@id='fname']")
	public WebElement F_name;
	@FindBy(xpath = "//input[@id='lname']")
	public WebElement L_name;
	@FindBy(xpath = "//input[@id='email']")
	public WebElement Email;
	@FindBy(xpath = "//textarea[@id='message']")
	public WebElement Address;
	@FindBy(xpath = "//input[@id='telephoneno']")
	public WebElement Phone_no;
	@FindBy(xpath = "//input[@name='submit']")
	public WebElement Submit_btn;
	@FindBy(xpath = "//input[@class='alt']")
	public WebElement Reset_btn;

//	Access Details...
	@FindBy(xpath = "//ul[@class='actions']//a[.='Home']")
	public WebElement Home;
	@FindBy(css = "td:nth-of-type(2)")
	public WebElement C_iD;

//	Add Tariff Plan
	@FindBy(xpath = "//a[.='Add Tariff Plan']")
	public WebElement Click_Add_Tariff_Plan;

	@FindBy(xpath = "//input[@name='rental']")
	public WebElement Monthly_Rental;
	@FindBy(xpath = "//input[@id='local_minutes']")
	public WebElement Local_Minutes;
	@FindBy(xpath = "//input[@id='inter_minutes']")
	public WebElement International_Minutes;
	@FindBy(xpath = "//input[@id='sms_pack']")
	public WebElement SmS_Pack;
	@FindBy(xpath = "//input[@id='minutes_charges']")
	public WebElement Local_min_charges;
	@FindBy(xpath = "//input[@id='inter_charges']")
	public WebElement International_Min_Charges;
	@FindBy(xpath = "//input[@id='sms_charges']")
	public WebElement SMS_charges;
	@FindBy(xpath = "//input[@name='submit']")
	public WebElement Submit_Add_Tariff_Plan;
	@FindBy(xpath = "//input[@class='alt']")
	public WebElement Reset_Add_Tariff_Plan;

//	Congrats page..

	@FindBy(xpath = "//ul[@class='actions']//a[.='Home']")
	public WebElement Home_Congrats;

//	AddTraiff plan to cust
	@FindBy(xpath = "//div[@class='flex-item left']//a[.='Add Tariff Plan to Customer']")
	public WebElement Add_Tar_to_Cust;

	@FindBy(css = "[for='sele']")
	public WebElement Radiobtn;

	@FindBy(xpath = "//input[@name='submit']")
	public WebElement AddTariff_btn;

//	CustomerID
	// input[@id='customer_id']
	@FindBy(xpath = "//input[@id='customer_id']")
	public WebElement Cust_ID;
	// input[@name='submit']
	@FindBy(xpath = "//input[@name='submit']")
	public WebElement submit_After_CID;

//	pay bill
	// div[@class='flex-item right']//a[.='Pay Billing']
	@FindBy(xpath = "//div[@class='flex-item right']//a[.='Pay Billing']")
	public WebElement PayBill;

	// input[@id='customer_id']
	// input[@name='submit']
	@FindBy(xpath = "//input[@id='customer_id']")
	public WebElement Paybill_custID;
	@FindBy(xpath = "//input[@name='submit']")
	public WebElement PayBill_submit;

//	@FindBy(xpath = "//label[1]")
//	public WebElement Approved_Tariff;
//	@FindBy(xpath = "//input[@name='submit']")
//	public WebElement Add_Tariff;
	@FindBy(xpath = "//ul[@class='actions']//a[.='Home']")
	public WebElement pay_Home;

	public AddCustomer_elements(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
